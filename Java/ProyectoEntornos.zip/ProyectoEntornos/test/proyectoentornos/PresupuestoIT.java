/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package proyectoentornos;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author raulg
 */
public class PresupuestoIT {
    
    public PresupuestoIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of seleccionarServicio method, of class Presupuesto.
     */
    @Test
    public void testSeleccionarServicio() {
        System.out.println("seleccionarServicio");
        String servicio = "Marketing";
        Presupuesto instance = new Presupuesto();
        instance.seleccionarServicio(servicio);
        // TODO review the generated test code and remove the default call to fail.
    }

    /**
     * Test of mostrarServiciosSeleccionados method, of class Presupuesto.
     */
    @Test
    public void testMostrarServiciosSeleccionados() {
        System.out.println("mostrarServiciosSeleccionados");
        Presupuesto instance = new Presupuesto();
        instance.mostrarServiciosSeleccionados();
        // TODO review the generated test code and remove the default call to fail.
    }

    /**
     * Test of obtenerPresupuesto method, of class Presupuesto.
     */
    @Test
    public void testObtenerPresupuesto() {
        System.out.println("obtenerPresupuesto");
        Presupuesto instance = new Presupuesto();
        double expResult = 5;
        double result = instance.obtenerPresupuesto();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
    }

    /**
     * Test of main method, of class Presupuesto.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Presupuesto.main(args);
        // TODO review the generated test code and remove the default call to fail.
    }
    
}
