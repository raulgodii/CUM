/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoentornos;

/**
 *
 * @author raulg
 */
import java.util.HashMap;
import java.util.Map;

public class Login {
    private Map<String, String> users;

    public Login() {
        users = new HashMap<>();
        // Agregar usuarios y contraseñas
        users.put("usuario1", "contrasena1");
        users.put("usuario2", "contrasena2");
        users.put("usuario3", "contrasena3");
    }

    public boolean authenticate(String username, String password) {
        // Verificar si el usuario existe y la contraseña es correcta
        if (users.containsKey(username) && users.get(username).equals(password)) {
            return true; // Autenticación exitosa
        }
        return false; // Autenticación fallida
    }

    public static void main(String[] args) {
        Login login = new Login();

        // Ejemplo de uso
        String username = "usuario1";
        String password = "contrasena1";
        boolean isAuthenticated = login.authenticate(username, password);

        if (isAuthenticated) {
            System.out.println("Inicio de sesión exitoso");
        } else {
            System.out.println("Inicio de sesión fallido");
        }
    }
}
