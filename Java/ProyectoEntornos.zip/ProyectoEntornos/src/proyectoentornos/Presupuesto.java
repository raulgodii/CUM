/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoentornos;

/**
 *
 * @author raulg
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Presupuesto {
    private Map<String, Double> preciosServicios;
    private List<String> serviciosSeleccionados;

    public Presupuesto() {
        preciosServicios = new HashMap<>();
        serviciosSeleccionados = new ArrayList<>();

        // Configurar los precios de los servicios
        preciosServicios.put("Marketing", 500.0);
        preciosServicios.put("Publicidad", 1000.0);
        preciosServicios.put("Community Manager", 800.0);
        preciosServicios.put("Diseño gráfico", 600.0);
        preciosServicios.put("Desarrollo web", 1500.0);
    }

    public void seleccionarServicio(String servicio) {
        // Verificar si el servicio está disponible y agregarlo a la lista de servicios seleccionados
        if (preciosServicios.containsKey(servicio)) {
            serviciosSeleccionados.add(servicio);
            System.out.println("Servicio \"" + servicio + "\" seleccionado.");
        } else {
            System.out.println("El servicio \"" + servicio + "\" no está disponible.");
        }
    }

    public void mostrarServiciosSeleccionados() {
        System.out.println("Servicios seleccionados:");
        for (String servicio : serviciosSeleccionados) {
            System.out.println("- " + servicio);
        }
    }

    public double obtenerPresupuesto() {
        double presupuestoTotal = 0.0;
        for (String servicio : serviciosSeleccionados) {
            if (preciosServicios.containsKey(servicio)) {
                presupuestoTotal += preciosServicios.get(servicio);
            }
        }
        return presupuestoTotal;
    }

    public static void main(String[] args) {
        Presupuesto presupuesto = new Presupuesto();

        // Ejemplo de uso
        presupuesto.seleccionarServicio("Marketing");
        presupuesto.seleccionarServicio("Publicidad");
        presupuesto.seleccionarServicio("Desarrollo web");
        presupuesto.seleccionarServicio("SEO"); // Servicio no disponible

        presupuesto.mostrarServiciosSeleccionados();

        double totalPresupuesto = presupuesto.obtenerPresupuesto();
        System.out.println("Presupuesto total: $" + totalPresupuesto);
    }
}
